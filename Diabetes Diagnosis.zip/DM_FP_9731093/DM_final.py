import sys
import numpy as np
from PIL import Image


class Main:
    def __init__(self):
        self.name="armina"




if __name__ == '__main__':
    sys.exit("Hello")
    im = Image.open('lena.jpg')
    im.show()
